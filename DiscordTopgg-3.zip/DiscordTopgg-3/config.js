module.exports = {
  bot: {
    token: "ODY5ODk4Mjk3MjU3NjQ0MDMy.GjgLud.DqRj6fAPN3a_eBlAvaa-5sx42McVYl5YV6NHNg",
    prefix: "-",
    owners: ["701010697244639293"],
    mongourl: "mongodb+srv://tomm:S2PPBMPopVLLYMuF@cluster0.b8usack.mongodb.net/vcodes?retryWrites=true&w=majority"
  },

  website: {
    callback: "https://2564a3ca-5fec-4921-b524-c2f8641d0648-00-2frn6qysj7x7e.wesley.replit.dev/callback",
    secret: "BTGRGMwR-87K3pPnb-KIzbma8U_iIt1h",
    clientID: "864409938758860801",
    tags: ["Moderation", "Fun", "Minecraft", "Economy", "Guard", "NSFW", "Anime", "Invite", "Music", "Logging", "Web Dashboard", "Reddit", "Youtube", "Twitch", "Crypto", "Leveling", "Game", "Roleplay", "Utility"]
  },

  server: {
    id: "851559990865952789",
    roles: {
      yonetici: "851560973659668522",
      moderator: "851560974791999498",
      profile: {
        booster: "863337213806903337",
        sponsor: "864059059081445387",
        supporter: "864058943076696066",
        partnerRole: "864059059081445387"
      },
      codeshare: {
        javascript: "JS",
        html: "HTML",
        altyapilar: "substructure",
        bdfd: "BDFD",
        besdavet: "5 INVITES",
        ondavet: "10 INVITES",
        onbesdavet: "15 INVITES",
        yirmidavet: "20 INVITES"
      },
      botlist: {
        developer: "864070638092550165",
        certified_developer: "864070763442470943",
        bot: "851561003619581983",
        certified_bot: "864071047287930880"
      }
    },
     channels: {
      codelog: "864056552885583872",
      login: "864056890874265650",
      webstatus: "864056719457124392",
      uptimelog: "864056890874265650",
      botlog: "864056552885583872",
      votes: "864056552885583872"
    }
  }

}